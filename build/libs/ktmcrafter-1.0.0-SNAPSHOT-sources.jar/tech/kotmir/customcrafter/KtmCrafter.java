package tech.kotmir.customcrafter;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1714;
import net.minecraft.class_1726;
import net.minecraft.class_2561;
import net.minecraft.class_3803;
import net.minecraft.class_3910;
import net.minecraft.class_3914;
import net.minecraft.class_3971;
import net.minecraft.class_4862;
import net.minecraft.class_747;
import net.minecraft.screen.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import tech.kotmir.customcrafter.network.OpenStationPayload;
import tech.kotmir.customcrafter.network.SaveRecipePayload;
import tech.kotmir.customcrafter.screen.RecipeEditorScreenHandler;

public class KtmCrafter implements ModInitializer {
    public static final String MOD_ID = "ktmcrafter";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Initializing KtmCrafter...");

        PayloadTypeRegistry.playC2S().register(OpenStationPayload.ID, OpenStationPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SaveRecipePayload.ID, SaveRecipePayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(OpenStationPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                var player = context.player();

                switch (payload.stationId()) {
                    case "editor" -> openEditor(player);
                    case "crafting_table" -> player.method_17355(new class_747(
                            (syncId, inv, p) -> new class_1714(syncId, inv, class_3914.field_17304),
                            class_2561.method_43470("Верстак Крафта")
                    ));
                    case "stonecutter" -> player.method_17355(new class_747(
                            (syncId, inv, p) -> new class_3971(syncId, inv, class_3914.field_17304),
                            class_2561.method_43470("Камнерез")
                    ));
                    case "smithing_table" -> player.method_17355(new class_747(
                            (syncId, inv, p) -> new class_4862(syncId, inv, class_3914.field_17304),
                            class_2561.method_43470("Кузнечный Верстак")
                    ));
                    case "loom" -> player.method_17355(new class_747(
                            (syncId, inv, p) -> new class_1726(syncId, inv, class_3914.field_17304),
                            class_2561.method_43470("Ткацкий Станок")
                    ));
                    case "cartography_table" -> player.method_17355(new class_747(
                            (syncId, inv, p) -> new class_3910(syncId, inv, class_3914.field_17304),
                            class_2561.method_43470("Стол Картографа")
                    ));
                    case "grindstone" -> player.method_17355(new class_747(
                            (syncId, inv, p) -> new class_3803(syncId, inv, class_3914.field_17304),
                            class_2561.method_43470("Точило")
                    ));
                }
            });
        });
    }

    public static void openEditor(net.minecraft.class_3222 player) {
        player.method_17355(new class_747(
                (syncId, inv, p) -> new RecipeEditorScreenHandler(syncId, inv),
                class_2561.method_43470("Редактор Кастомных Крафтов")
        ));
    }
}