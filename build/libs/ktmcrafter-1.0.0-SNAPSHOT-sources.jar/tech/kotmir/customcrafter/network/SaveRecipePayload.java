package tech.kotmir.customcrafter.network;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import tech.kotmir.customcrafter.KtmCrafter;

public record SaveRecipePayload() implements class_8710 {
    public static final class_8710.class_9154<SaveRecipePayload> ID = new class_8710.class_9154<>(class_2960.method_60655(KtmCrafter.MOD_ID, "save_recipe"));
    public static final class_9139<class_9129, SaveRecipePayload> CODEC = class_9139.method_56431(new SaveRecipePayload());

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}