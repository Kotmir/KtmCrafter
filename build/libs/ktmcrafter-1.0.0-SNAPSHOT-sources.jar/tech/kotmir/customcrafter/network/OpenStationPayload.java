package tech.kotmir.customcrafter.network;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record OpenStationPayload(String stationId) implements class_8710 {
    public static final class_8710.class_9154<OpenStationPayload> ID = new class_8710.class_9154<>(class_2960.method_60655("ktmcrafter", "open_station"));
    public static final class_9139<class_9129, OpenStationPayload> CODEC = class_9139.method_56434(
            class_9135.field_48554, OpenStationPayload::stationId,
            OpenStationPayload::new
    );

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}