package tech.kotmir.customcrafter.screen;

import tech.kotmir.customcrafter.KtmCrafter;

import java.util.Set;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3917;

public class RecipeEditorScreenHandler extends class_1703 {
    private final class_1263 inventory = new class_1277(54);
    
    // Слоты сетки крафта 3x3 и слот результата 25
    private static final Set<Integer> EDITABLE_SLOTS = Set.of(
            10, 11, 12,
            19, 20, 21,
            28, 29, 30,
            25
    );

    public RecipeEditorScreenHandler(int syncId, class_1661 playerInventory) {
        super(class_3917.field_17327, syncId);

        // Заполнение фоновым стеклом
        class_1799 grayGlass = new class_1799(class_1802.field_8871);
        for (int i = 0; i < 54; i++) {
            if (!EDITABLE_SLOTS.contains(i)) {
                inventory.method_5447(i, grayGlass.method_7972());
            }
        }

        // Верстак и Изумруд
        inventory.method_5447(23, new class_1799(class_1802.field_8465));
        class_1799 emerald = new class_1799(class_1802.field_8687);
        emerald.method_57379(net.minecraft.class_9334.field_49631, class_2561.method_43470("§a§lСохранить рецепт"));
        inventory.method_5447(41, emerald);

        // Добавление 54 слотов
        for (int row = 0; row < 6; row++) {
            for (int col = 0; col < 9; col++) {
                int index = col + row * 9;
                this.method_7621(new class_1735(inventory, index, 8 + col * 18, 18 + row * 18) {
                    @Override
                    public boolean method_7680(class_1799 stack) {
                        return EDITABLE_SLOTS.contains(index);
                    }

                    @Override
                    public boolean method_7674(class_1657 playerEntity) {
                        return EDITABLE_SLOTS.contains(index);
                    }
                });
            }
        }

        // Инвентарь игрока
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.method_7621(new class_1735(playerInventory, col + row * 9 + 9, 8 + col * 18, 140 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.method_7621(new class_1735(playerInventory, col, 8 + col * 18, 198));
        }
    }

    @Override
    public void method_7593(int slotIndex, int button, class_1713 actionType, class_1657 player) {
        if (slotIndex == 41) { // Клик по изумруду
            saveRecipe(player);
            return;
        }
        super.method_7593(slotIndex, button, actionType, player);
    }

    private void saveRecipe(class_1657 player) {
        class_1799 output = inventory.method_5438(25);
        if (output.method_7960()) {
            player.method_7353(class_2561.method_43470("§cОшибка: Положите предмет результата в слот 25!"), false);
            return;
        }

        KtmCrafter.LOGGER.info("Сохранение кастомного рецепта для: {}", output.method_7909().method_63680().getString());
        player.method_7353(class_2561.method_43470("§aРецепт для " + output.method_7909().method_63680().getString() + " успешно сохранён!"), false);
    }

    @Override
    public class_1799 method_7601(class_1657 player, int invSlot) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }
}