package tech.kotmir.customcrafter.client;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_10799;
import net.minecraft.class_11909;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;
import tech.kotmir.customcrafter.network.OpenStationPayload;

import java.util.ArrayList;
import java.util.List;

public class CustomCrafterScreen extends class_437 {
    private static final class_2960 CONTAINER_TEXTURE = class_2960.method_60655("minecraft", "textures/gui/container/generic_54.png");

    private static final int BG_WIDTH = 176;
    private static final int BG_HEIGHT = 222;
    private int x, y;
    private int currentPage = 0; // 0 = Стр. 1, 1 = Стр. 2

    private final class_1799[] page1Slots = new class_1799[54];
    private final class_1799[] page2Slots = new class_1799[54];

    public CustomCrafterScreen() {
        super(class_2561.method_43470("KtmCrafter"));
        setupPages();
    }

    private void setupPages() {
        class_1799 blackGlass = new class_1799(class_1802.field_8157);
        class_1799 arrowNext = new class_1799(class_1802.field_8107);
        class_1799 arrowPrev = new class_1799(class_1802.field_8107);
        class_1799 greenBook = new class_1799(class_1802.field_8361);

        for (int i = 0; i < 54; i++) {
            page1Slots[i] = blackGlass.method_7972();
            page2Slots[i] = blackGlass.method_7972();
        }

        // === СТРАНИЦА 1 ===
        page1Slots[10] = new class_1799(class_1802.field_8465);  // Верстак
        page1Slots[12] = new class_1799(class_1802.field_16308);  // Стол кузнеца
        page1Slots[14] = new class_1799(class_1802.field_8772);            // Ткацкий станок
        page1Slots[16] = new class_1799(class_1802.field_16313); // Стол картографа

        page1Slots[22] = greenBook.method_7972();                     // Зеленая книга
        page1Slots[26] = arrowNext;                            // Переход на стр. 2

        page1Slots[28] = new class_1799(class_1802.field_8732);         // Печь
        page1Slots[30] = new class_1799(class_1802.field_16306);   // Доменная печь
        page1Slots[32] = new class_1799(class_1802.field_16309);          // Коптильня
        page1Slots[34] = new class_1799(class_1802.field_16310); // Стол лучника

        // === СТРАНИЦА 2 ===
        page2Slots[10] = new class_1799(class_1802.field_16305);     // Камнерез
        page2Slots[12] = new class_1799(class_1802.field_16311);      // Точило

        page2Slots[18] = arrowPrev;                            // Переход на стр. 1
        page2Slots[22] = greenBook.method_7972();                     // Зеленая книга

        page2Slots[28] = new class_1799(class_1802.field_17346);        // Костер
        page2Slots[30] = new class_1799(class_1802.field_23842);   // Костер душ
        page2Slots[32] = new class_1799(class_1802.field_8740);   // Зельеварение
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        this.x = (this.field_22789 - BG_WIDTH) / 2;
        this.y = (this.field_22790 - BG_HEIGHT) / 2;
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        if (click.method_74245() == 0) {
            int slot = getHoveredSlot(click.comp_4798(), click.comp_4799());
            if (slot != -1) {
                handleSlotClick(slot);
                return true;
            }
        }
        return super.method_25402(click, doubled);
    }

    private void handleSlotClick(int slot) {
        if (currentPage == 0) {
            switch (slot) {
                case 26 -> currentPage = 1; // Переход на страницу 2
                case 10 -> openStation("crafting_table");
                case 12 -> openStation("smithing_table");
                case 14 -> openStation("loom");
                case 16 -> openStation("cartography_table");
                case 28 -> openStation("furnace");
                case 30 -> openStation("blast_furnace");
                case 32 -> openStation("smoker");
                case 34 -> openStation("fletching_table");
            }
        } else if (currentPage == 1) {
            switch (slot) {
                case 18 -> currentPage = 0; // Переход на страницу 1
                case 10 -> openStation("stonecutter");
                case 12 -> openStation("grindstone");
                case 28 -> openStation("campfire");
                case 30 -> openStation("soul_campfire");
                case 32 -> openStation("brewing_stand");
            }
        }
    }

    private void openStation(String stationId) {
        ClientPlayNetworking.send(new OpenStationPayload(stationId));
    }

    private int getHoveredSlot(double mouseX, double mouseY) {
        for (int i = 0; i < 54; i++) {
            int col = i % 9;
            int row = i / 9;
            int slotX = this.x + 7 + col * 18;
            int slotY = this.y + 17 + row * 18;

            if (mouseX >= slotX && mouseX < slotX + 18 && mouseY >= slotY && mouseY < slotY + 18) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25290(
                class_10799.field_56883,
                CONTAINER_TEXTURE,
                this.x,
                this.y,
                0.0f,
                0.0f,
                BG_WIDTH,
                BG_HEIGHT,
                256,
                256
        );

        context.method_51439(this.field_22793, this.field_22785, this.x + 8, this.y + 6, 0x404040, false);

        class_1799[] currentSlots = (currentPage == 0) ? page1Slots : page2Slots;
        int hoveredSlot = getHoveredSlot(mouseX, mouseY);

        for (int i = 0; i < 54; i++) {
            int col = i % 9;
            int row = i / 9;
            int slotX = this.x + 8 + col * 18;
            int slotY = this.y + 18 + row * 18;

            class_1799 stack = currentSlots[i];
            if (!stack.method_7960()) {
                context.method_51427(stack, slotX, slotY);
            }
        }

        if (hoveredSlot != -1) {
            class_1799 hoveredStack = currentSlots[hoveredSlot];
            if (!hoveredStack.method_7960() && hoveredStack.method_7909() != class_1802.field_8157) {
                List<class_2561> tooltip = createCustomTooltip(hoveredSlot, currentPage);
                if (!tooltip.isEmpty()) {
                    context.method_51434(this.field_22793, tooltip, mouseX, mouseY);
                }
            }
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    private List<class_2561> createCustomTooltip(int slot, int page) {
        List<class_2561> list = new ArrayList<>();

        if (slot == 22) {
            list.add(class_2561.method_43470("§a§l📖 KtmCrafter — Справка"));
            list.add(class_2561.method_43470("§7Нажимайте на блоки оборудования,"));
            list.add(class_2561.method_43470("§7чтобы открыть кастомные крафты."));
            list.add(class_2561.method_43470(""));
            list.add(class_2561.method_43470("§e💡 Навигация: §fСтрелочки по бокам"));
            return list;
        }

        if (page == 0) {
            switch (slot) {
                case 10 -> {
                    list.add(class_2561.method_43470("§6§l📦 Верстак Крафта"));
                    list.add(class_2561.method_43470("§7Основной верстак для создания"));
                    list.add(class_2561.method_43470("§7уникальных предметов и компонентов."));
                    list.add(class_2561.method_43470(""));
                    list.add(class_2561.method_43470("§e▶ Нажмите для открытия"));
                }
                case 12 -> {
                    list.add(class_2561.method_43470("§b§l⚒️ Кузнечный Верстак"));
                    list.add(class_2561.method_43470("§7Улучшение снаряжения, ковка Незерита"));
                    list.add(class_2561.method_43470("§7и нанесение особых рун."));
                    list.add(class_2561.method_43470(""));
                    list.add(class_2561.method_43470("§e▶ Нажмите для открытия"));
                }
                case 14 -> {
                    list.add(class_2561.method_43470("§d§l🧵 Ткацкий Станок"));
                    list.add(class_2561.method_43470("§7Создание кастомных флагов, узоров"));
                    list.add(class_2561.method_43470("§7и декоративных тканей."));
                    list.add(class_2561.method_43470(""));
                    list.add(class_2561.method_43470("§e▶ Нажмите для открытия"));
                }
                case 16 -> {
                    list.add(class_2561.method_43470("§e§l🗺️ Стол Картографа"));
                    list.add(class_2561.method_43470("§7Исследование территорий, копирование"));
                    list.add(class_2561.method_43470("§7и расширение секретных карт."));
                    list.add(class_2561.method_43470(""));
                    list.add(class_2561.method_43470("§e▶ Нажмите для открытия"));
                }
                case 26 -> {
                    list.add(class_2561.method_43470("§a§lВперёд ▶"));
                    list.add(class_2561.method_43470("§7Перейти на страницу 2"));
                }
                case 28 -> {
                    list.add(class_2561.method_43470("§c§l🔥 Плавильная Печь"));
                    list.add(class_2561.method_43470("§7Классическая обжарка руд и материалов."));
                    list.add(class_2561.method_43470(""));
                    list.add(class_2561.method_43470("§e▶ Нажмите для открытия"));
                }
                case 30 -> {
                    list.add(class_2561.method_43470("§7§l🌋 Доменная Печь"));
                    list.add(class_2561.method_43470("§7Ускоренная в 2 раза плавка металлов."));
                    list.add(class_2561.method_43470(""));
                    list.add(class_2561.method_43470("§e▶ Нажмите для открытия"));
                }
                case 32 -> {
                    list.add(class_2561.method_43470("§6§l🍗 Коптильня"));
                    list.add(class_2561.method_43470("§7Быстрое приготовление изысканной еды."));
                    list.add(class_2561.method_43470(""));
                    list.add(class_2561.method_43470("§e▶ Нажмите для открытия"));
                }
                case 34 -> {
                    list.add(class_2561.method_43470("§g§l🏹 Стол Лучника"));
                    list.add(class_2561.method_43470("§7Создание особых стрел с эффектами."));
                    list.add(class_2561.method_43470(""));
                    list.add(class_2561.method_43470("§e▶ Нажмите для открытия"));
                }
            }
        } else if (page == 1) {
            switch (slot) {
                case 10 -> {
                    list.add(class_2561.method_43470("§f§l🪨 Камнерез"));
                    list.add(class_2561.method_43470("§7Быстрая обработка камня и минералов."));
                    list.add(class_2561.method_43470(""));
                    list.add(class_2561.method_43470("§e▶ Нажмите для открытия"));
                }
                case 12 -> {
                    list.add(class_2561.method_43470("§8§l⚙️ Точило"));
                    list.add(class_2561.method_43470("§7Снятие зачарований и ремонт вещей."));
                    list.add(class_2561.method_43470(""));
                    list.add(class_2561.method_43470("§e▶ Нажмите для открытия"));
                }
                case 18 -> {
                    list.add(class_2561.method_43470("§c§l◀ Назад"));
                    list.add(class_2561.method_43470("§7Вернуться на страницу 1"));
                }
                case 28 -> {
                    list.add(class_2561.method_43470("§6§l🔥 Костёр"));
                    list.add(class_2561.method_43470("§7Медленная жарка пищи без топлива."));
                    list.add(class_2561.method_43470(""));
                    list.add(class_2561.method_43470("§e▶ Нажмите для открытия"));
                }
                case 30 -> {
                    list.add(class_2561.method_43470("§b§l👻 Костёр Душ"));
                    list.add(class_2561.method_43470("§7Мистический огонь для ритуалов."));
                    list.add(class_2561.method_43470(""));
                    list.add(class_2561.method_43470("§e▶ Нажмите для открытия"));
                }
                case 32 -> {
                    list.add(class_2561.method_43470("§2§l🧪 Зельеварение"));
                    list.add(class_2561.method_43470("§7Варочная стойка для редких зелий."));
                    list.add(class_2561.method_43470(""));
                    list.add(class_2561.method_43470("§e▶ Нажмите для открытия"));
                }
            }
        }

        return list;
    }

    @Override
    public boolean method_25422() {
        return true;
    }
}