package tech.kotmir.customcrafter.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import org.lwjgl.glfw.GLFW;

public class KtmCrafterClient implements ClientModInitializer {
    private static class_304 openMenuKey;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.ktmcrafter.open_menu",
                GLFW.GLFW_KEY_G,
                class_304.class_11900.field_62556
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.method_1436()) {
                if (client.field_1724 != null) {
                    client.method_1507(new CustomCrafterScreen());
                }
            }
        });
    }
}