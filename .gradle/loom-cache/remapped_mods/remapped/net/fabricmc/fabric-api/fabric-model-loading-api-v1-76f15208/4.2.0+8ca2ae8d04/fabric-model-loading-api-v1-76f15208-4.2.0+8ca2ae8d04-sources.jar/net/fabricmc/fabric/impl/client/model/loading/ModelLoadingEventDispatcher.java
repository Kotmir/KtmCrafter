/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.client.model.loading;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import com.google.common.collect.ImmutableList;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceMap;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceOpenHashMap;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.fabricmc.fabric.api.client.model.loading.v1.BlockStateResolver;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.class_1091;
import net.minecraft.class_9979;
import net.minecraft.client.render.block.BlockModels;
import net.minecraft.client.render.model.Baker;
import net.minecraft.client.render.model.BlockStateModel;
import net.minecraft.client.render.model.BlockStatesLoader;
import net.minecraft.client.render.model.ModelBakeSettings;
import net.minecraft.client.render.model.UnbakedModel;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.Identifier;

public class ModelLoadingEventDispatcher {
	private static final Logger LOGGER = LoggerFactory.getLogger(ModelLoadingEventDispatcher.class);
	public static final ThreadLocal<ModelLoadingEventDispatcher> CURRENT = new ThreadLocal<>();

	private final ModelLoadingPluginContextImpl pluginContext;

	private final BlockStateResolverContext blockStateResolverContext = new BlockStateResolverContext();

	private final OnLoadModifierContext onLoadModifierContext = new OnLoadModifierContext();
	private final ObjectArrayList<BeforeBakeModifierContext> beforeBakeModifierContextStack = new ObjectArrayList<>();
	private final ObjectArrayList<AfterBakeModifierContext> afterBakeModifierContextStack = new ObjectArrayList<>();

	private final OnLoadBlockModifierContext onLoadBlockModifierContext = new OnLoadBlockModifierContext();
	private final BeforeBakeBlockModifierContext beforeBakeBlockModifierContext = new BeforeBakeBlockModifierContext();
	private final AfterBakeBlockModifierContext afterBakeBlockModifierContext = new AfterBakeBlockModifierContext();

	public ModelLoadingEventDispatcher(List<ModelLoadingPlugin> plugins) {
		this.pluginContext = new ModelLoadingPluginContextImpl();

		for (ModelLoadingPlugin plugin : plugins) {
			try {
				plugin.initialize(pluginContext);
			} catch (Exception exception) {
				LOGGER.error("Failed to initialize model loading plugin", exception);
			}
		}
	}

	public void forEachExtraModel(Consumer<Identifier> extraModelConsumer) {
		pluginContext.extraModels.forEach(extraModelConsumer);
	}

	@Nullable
	public UnbakedModel modifyModelOnLoad(@Nullable UnbakedModel model, Identifier id) {
		onLoadModifierContext.prepare(id);
		return pluginContext.modifyModelOnLoad().invoker().modifyModelOnLoad(model, onLoadModifierContext);
	}

	public UnbakedModel modifyModelBeforeBake(UnbakedModel model, Identifier id, ModelBakeSettings settings, Baker baker) {
		if (beforeBakeModifierContextStack.isEmpty()) {
			beforeBakeModifierContextStack.add(new BeforeBakeModifierContext());
		}

		BeforeBakeModifierContext context = beforeBakeModifierContextStack.pop();
		context.prepare(id, settings, baker);

		model = pluginContext.modifyModelBeforeBake().invoker().modifyModelBeforeBake(model, context);

		beforeBakeModifierContextStack.push(context);
		return model;
	}

	public BlockStateModel modifyModelAfterBake(BlockStateModel model, Identifier id, UnbakedModel sourceModel, ModelBakeSettings settings, Baker baker) {
		if (afterBakeModifierContextStack.isEmpty()) {
			afterBakeModifierContextStack.add(new AfterBakeModifierContext());
		}

		AfterBakeModifierContext context = afterBakeModifierContextStack.pop();
		context.prepare(id, sourceModel, settings, baker);

		model = pluginContext.modifyModelAfterBake().invoker().modifyModelAfterBake(model, context);

		afterBakeModifierContextStack.push(context);
		return model;
	}

	public BlockStatesLoader.LoadedModels modifyBlockModelsOnLoad(BlockStatesLoader.LoadedModels models) {
		Map<class_1091, BlockStatesLoader.class_9825> map = models.models();

		if (!(map instanceof HashMap)) {
			map = new HashMap<>(map);
			models = new BlockStatesLoader.LoadedModels(map);
		}

		putResolvedBlockStates(map);

		map.replaceAll((id, blockModel) -> {
			class_9979 original = blockModel.comp_2871();
			class_9979 modified = modifyBlockModelOnLoad(original, id, blockModel.comp_3062());

			if (original != modified) {
				return new class_9824.class_9825(blockModel.comp_3062(), modified);
			}

			return blockModel;
		});

		return models;
	}

	private void putResolvedBlockStates(Map<class_1091, BlockStatesLoader.class_9825> map) {
		pluginContext.blockStateResolvers.forEach((block, resolver) -> {
			Optional<RegistryKey<Block>> optionalKey = Registries.BLOCK.getKey(block);

			if (optionalKey.isEmpty()) {
				return;
			}

			Identifier blockId = optionalKey.get().getValue();

			resolveBlockStates(resolver, block, (state, model) -> {
				class_1091 modelId = BlockModels.method_3336(blockId, state);
				map.put(modelId, new BlockStatesLoader.class_9825(state, model));
			});
		});
	}

	private void resolveBlockStates(BlockStateResolver resolver, Block block, BiConsumer<BlockState, class_9979> output) {
		BlockStateResolverContext context = blockStateResolverContext;
		context.prepare(block);

		Reference2ReferenceMap<BlockState, class_9979> resolvedModels = context.models;
		ImmutableList<BlockState> allStates = block.getStateManager().getStates();
		boolean thrown = false;

		try {
			resolver.resolveBlockStates(context);
		} catch (Exception e) {
			LOGGER.error("Failed to resolve block state models for block {}. Using missing model for all states.", block, e);
			thrown = true;
		}

		if (!thrown) {
			if (resolvedModels.size() == allStates.size()) {
				// If there are as many resolved models as total states, all states have
				// been resolved and models do not need to be null-checked.
				resolvedModels.forEach(output);
			} else {
				for (BlockState state : allStates) {
					@Nullable
					class_9979 model = resolvedModels.get(state);

					if (model == null) {
						LOGGER.error("Block state resolver did not provide a model for state {} in block {}. Using missing model.", state, block);
					} else {
						output.accept(state, model);
					}
				}
			}
		}

		resolvedModels.clear();
	}

	private class_9979 modifyBlockModelOnLoad(class_9979 model, class_1091 id, BlockState state) {
		onLoadBlockModifierContext.prepare(id, state);
		return pluginContext.modifyBlockModelOnLoad().invoker().modifyModelOnLoad(model, onLoadBlockModifierContext);
	}

	public class_9979 modifyBlockModelBeforeBake(class_9979 model, class_1091 id, Baker baker) {
		beforeBakeBlockModifierContext.prepare(id, baker);
		return pluginContext.modifyBlockModelBeforeBake().invoker().modifyModelBeforeBake(model, beforeBakeBlockModifierContext);
	}

	public BlockStateModel modifyBlockModelAfterBake(BlockStateModel model, class_1091 id, class_9979 sourceModel, Baker baker) {
		afterBakeBlockModifierContext.prepare(id, sourceModel, baker);
		return pluginContext.modifyBlockModelAfterBake().invoker().modifyModelAfterBake(model, afterBakeBlockModifierContext);
	}

	private static class BlockStateResolverContext implements BlockStateResolver.Context {
		private Block block;
		private final Reference2ReferenceMap<BlockState, class_9979> models = new Reference2ReferenceOpenHashMap<>();

		private void prepare(Block block) {
			this.block = block;
			models.clear();
		}

		@Override
		public Block block() {
			return block;
		}

		@Override
		public void setModel(BlockState state, class_9979 model) {
			Objects.requireNonNull(state, "state cannot be null");
			Objects.requireNonNull(model, "model cannot be null");

			if (!state.isOf(block)) {
				throw new IllegalArgumentException("Attempted to set model for state " + state + " on block " + block);
			}

			if (models.putIfAbsent(state, model) != null) {
				throw new IllegalStateException("Duplicate model for state " + state + " on block " + block);
			}
		}
	}

	private static class OnLoadModifierContext implements ModelModifier.OnLoad.Context {
		private Identifier id;

		private void prepare(Identifier id) {
			this.id = id;
		}

		@Override
		public Identifier id() {
			return id;
		}
	}

	private static class BeforeBakeModifierContext implements ModelModifier.BeforeBake.Context {
		private Identifier id;
		private ModelBakeSettings settings;
		private Baker baker;

		private void prepare(Identifier id, ModelBakeSettings settings, Baker baker) {
			this.id = id;
			this.settings = settings;
			this.baker = baker;
		}

		@Override
		public Identifier id() {
			return id;
		}

		@Override
		public ModelBakeSettings settings() {
			return settings;
		}

		@Override
		public Baker baker() {
			return baker;
		}
	}

	private static class AfterBakeModifierContext implements ModelModifier.AfterBake.Context {
		private Identifier id;
		private UnbakedModel sourceModel;
		private ModelBakeSettings settings;
		private Baker baker;

		private void prepare(Identifier id, UnbakedModel sourceModel, ModelBakeSettings settings, Baker baker) {
			this.id = id;
			this.sourceModel = sourceModel;
			this.settings = settings;
			this.baker = baker;
		}

		@Override
		public Identifier id() {
			return id;
		}

		@Override
		public UnbakedModel sourceModel() {
			return sourceModel;
		}

		@Override
		public ModelBakeSettings settings() {
			return settings;
		}

		@Override
		public Baker baker() {
			return baker;
		}
	}

	private static class OnLoadBlockModifierContext implements ModelModifier.OnLoadBlock.Context {
		private class_1091 id;
		private BlockState state;

		private void prepare(class_1091 id, BlockState state) {
			this.id = id;
			this.state = state;
		}

		@Override
		public class_1091 id() {
			return id;
		}

		@Override
		public BlockState state() {
			return state;
		}
	}

	private static class BeforeBakeBlockModifierContext implements ModelModifier.BeforeBakeBlock.Context {
		private class_1091 id;
		private Baker baker;

		private void prepare(class_1091 id, Baker baker) {
			this.id = id;
			this.baker = baker;
		}

		@Override
		public class_1091 id() {
			return id;
		}

		@Override
		public Baker baker() {
			return baker;
		}
	}

	private static class AfterBakeBlockModifierContext implements ModelModifier.AfterBakeBlock.Context {
		private class_1091 id;
		private class_9979 sourceModel;
		private Baker baker;

		private void prepare(class_1091 id, class_9979 sourceModel, Baker baker) {
			this.id = id;
			this.sourceModel = sourceModel;
			this.baker = baker;
		}

		@Override
		public class_1091 id() {
			return id;
		}

		@Override
		public class_9979 sourceModel() {
			return sourceModel;
		}

		@Override
		public Baker baker() {
			return baker;
		}
	}
}
