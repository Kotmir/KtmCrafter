/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.client.model.loading.v1;

import net.minecraft.client.render.model.Baker;
import net.minecraft.client.render.model.BlockStateModel;
import net.minecraft.client.render.model.ModelBakeSettings;
import net.minecraft.client.render.model.ModelTextures;
import net.minecraft.client.render.model.UnbakedModel;
import net.minecraft.client.render.model.json.ModelTransformation;
import org.jetbrains.annotations.Nullable;

/**
 * A simple implementation of {@link UnbakedModel} that delegates all method calls to the {@link #wrapped} field.
 * Implementations must set the {@link #wrapped} field somehow.
 */
public abstract class WrapperUnbakedModel implements UnbakedModel {
	protected UnbakedModel wrapped;

	protected WrapperUnbakedModel() {
	}

	protected WrapperUnbakedModel(UnbakedModel wrapped) {
		this.wrapped = wrapped;
	}

	@Override
	public void method_62326(class_10103 resolver) {
		wrapped.method_62326(resolver);
	}

	@Override
	public BlockStateModel method_4753(ModelTextures textures, Baker baker, ModelBakeSettings settings, boolean ambientOcclusion, boolean isSideLit, ModelTransformation transformation) {
		return wrapped.method_4753(textures, baker, settings, ambientOcclusion, isSideLit, transformation);
	}

	@Override
	@Nullable
	public Boolean method_65537() {
		return wrapped.method_65537();
	}

	@Override
	@Nullable
	public GuiLight method_24298() {
		return wrapped.method_24298();
	}

	@Override
	@Nullable
	public ModelTransformation method_65540() {
		return wrapped.method_65540();
	}

	@Override
	public ModelTextures.Textures method_65539() {
		return wrapped.method_65539();
	}

	@Override
	@Nullable
	public UnbakedModel method_65538() {
		return wrapped.method_65538();
	}
}
